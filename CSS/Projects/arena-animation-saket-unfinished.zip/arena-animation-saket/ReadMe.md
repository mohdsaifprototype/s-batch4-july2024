1. Graphical Content
2. Text Content
3. Interactive Content
4. Icons
